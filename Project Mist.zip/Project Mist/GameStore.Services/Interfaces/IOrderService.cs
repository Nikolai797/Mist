﻿using System.Collections.Generic;
using System.Threading.Tasks;
using GameStore.Data.Entities;

namespace GameStore.Services.Interfaces
{
    public interface IOrderService
    {
        Task<Order> CreateOrderAsync(string userId, List<CartItem> cartItems);
        Task<Order> GetOrderByIdAsync(int id);
        Task<IEnumerable<Order>> GetUserOrdersAsync(string userId);
    }
}