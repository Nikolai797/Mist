﻿using System.Collections.Generic;

namespace GameStore.Services.Interfaces
{
    public interface ICartService
    {
        void AddToCart(int gameId, string userId);
        void RemoveFromCart(int gameId, string userId);
        List<CartItem> GetCartItems(string userId);
        void ClearCart(string userId);
        decimal GetTotal(string userId);
    }
}