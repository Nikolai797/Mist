﻿using System.Collections.Generic;
using System.Linq;
using GameStore.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace GameStore.Services.Implementations
{
    public class CartService : ICartService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IGameService _gameService;
        private const string CartSessionKey = "Cart";

        public CartService(IHttpContextAccessor httpContextAccessor, IGameService gameService)
        {
            _httpContextAccessor = httpContextAccessor;
            _gameService = gameService;
        }

        private ISession Session => _httpContextAccessor.HttpContext.Session;

        private List<CartItem> GetCart()
        {
            var session = Session;
            string cartJson = session.GetString(CartSessionKey);
            if (string.IsNullOrEmpty(cartJson))
                return new List<CartItem>();
            return JsonConvert.DeserializeObject<List<CartItem>>(cartJson);
        }

        private void SaveCart(List<CartItem> cart)
        {
            var session = Session;
            string cartJson = JsonConvert.SerializeObject(cart);
            session.SetString(CartSessionKey, cartJson);
        }

        public void AddToCart(int gameId, string userId)
        {
            var cart = GetCart();
            var existingItem = cart.FirstOrDefault(x => x.GameId == gameId && x.UserId == userId);
            if (existingItem != null)
            {
                existingItem.Quantity++;
            }
            else
            {
                var game = _gameService.GetGameByIdAsync(gameId).Result;
                cart.Add(new CartItem
                {
                    GameId = gameId,
                    GameTitle = game.Title,
                    Price = game.Price,
                    Quantity = 1,
                    UserId = userId
                });
            }
            SaveCart(cart);
        }

        public void RemoveFromCart(int gameId, string userId)
        {
            var cart = GetCart();
            var item = cart.FirstOrDefault(x => x.GameId == gameId && x.UserId == userId);
            if (item != null)
            {
                if (item.Quantity > 1)
                    item.Quantity--;
                else
                    cart.Remove(item);
            }
            SaveCart(cart);
        }

        public List<CartItem> GetCartItems(string userId)
        {
            return GetCart().Where(x => x.UserId == userId).ToList();
        }

        public void ClearCart(string userId)
        {
            var cart = GetCart();
            cart.RemoveAll(x => x.UserId == userId);
            SaveCart(cart);
        }

        public decimal GetTotal(string userId)
        {
            return GetCartItems(userId).Sum(x => x.Price * x.Quantity);
        }
    }
}